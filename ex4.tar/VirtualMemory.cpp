#include "VirtualMemory.h"
#include "PhysicalMemory.h"
#include <cmath>


void clearFrame(uint64_t frameIndex) {
    for (uint64_t i = 0; i < PAGE_SIZE; ++i) {
        PMwrite(frameIndex * PAGE_SIZE + i, 0);
    }
}

/**
 * Calculating the cyclic distance between pages
 * @param currentPage current page number
 * @param targetPage the page we want to swap in
 * @return the "distance"
 */
uint64_t calculateCyclicDistance(uint64_t currentPage, uint64_t targetPage) {
    uint64_t distance1 = NUM_PAGES - std::abs(int64_t(targetPage) - int64_t(currentPage));
    uint64_t distance2 = std::abs(int64_t(targetPage) - int64_t(currentPage));
    uint64_t distance = distance1 < distance2 ? distance1 : distance2;
    return distance;
}

/**
 * DFS Function to gather required data
 * @param targetPage the address we are in (it is the page number without offset)
 * @param maxFrameIndex the value of the maximum index visited in the RAM
 * @param parentFrameIndex the frame's index that called the function
 * @param emptyFrameIndex solution for option 1
 * @param currentPage current page number
 * @param pageToEvict for option 3 - the number of the page we want to evict
 * @param frameToEvict for option 3 - the number of the frame we want to evict
 * @param currentDepth our current depth
 * @param currentFrame the current frame
 * @param parentFrame the parent of the current node (in the DFS)
 * @param positionInParent my position (page index) in my parent (frame)
 * @param parentPageToEvict for option 3 - the parent of the frame to be evicted
 * @param positionInParentPage for option 3 - the position in the parent of the frame to be evicted
 * @param isEmptyFrame a flag to indicate if we already visited the leaves
 */
void dfs(uint64_t targetPage, word_t* maxFrameIndex, uint64_t parentFrameIndex, uint64_t* emptyFrameIndex,
         uint64_t currentPage, uint64_t* pageToEvict, uint64_t* frameToEvict, uint64_t currentDepth,
         uint64_t currentFrame, uint64_t parentFrame, uint64_t positionInParent,
         uint64_t* parentPageToEvict, uint64_t* positionInParentPage, bool* isEmptyFrame) {

    if (currentDepth == TABLES_DEPTH) {
        uint64_t currentCyclicDistance = calculateCyclicDistance(currentPage, targetPage);
        uint64_t minCyclicDistance = calculateCyclicDistance(*pageToEvict, targetPage);

        if ((currentCyclicDistance > minCyclicDistance) || (!(*isEmptyFrame))) {
            *pageToEvict = currentPage;
            *frameToEvict = currentFrame;
            *parentPageToEvict = parentFrame;
            *positionInParentPage = positionInParent;
            *isEmptyFrame = true;
        }
        return;
    }

    currentPage = currentPage << OFFSET_WIDTH;
    bool allEntriesEmpty = true;
    for (int i = 0; i < PAGE_SIZE; i++) {
        word_t value;
        PMread(currentFrame * PAGE_SIZE + i, &value);
        if (value != 0) {
            allEntriesEmpty = false;
            if (value > (*maxFrameIndex)) {
                *maxFrameIndex = value;
            }

            dfs(targetPage, maxFrameIndex, parentFrameIndex, emptyFrameIndex,
                currentPage + i, pageToEvict, frameToEvict, currentDepth + 1, value,
                currentFrame, i, parentPageToEvict, positionInParentPage, isEmptyFrame);
        }
    }
    if (allEntriesEmpty && (parentFrameIndex != currentFrame) && ((*emptyFrameIndex) == 0)) {
        *emptyFrameIndex = currentFrame;
        PMwrite(uint64_t((parentFrame * PAGE_SIZE) + positionInParent), 0);
    }
}

/**
 * Finds an address to evict by considering different scenarios
 * @return address of the frame to evict
 */
uint64_t findEvictionAddress(uint64_t virtualAddress, uint64_t parentFrame, int depth) {
    bool isFrameEmpty = false;
    word_t maxFrameIndex = 0;
    uint64_t emptyFrameIndex = 0;
    uint64_t pageToEvict = 0;
    uint64_t frameToEvict = 0;
    uint64_t parentPageToEvict = 0;
    uint64_t positionInParentPage = 0;

    // Perform DFS to determine the frame to evict
    dfs(virtualAddress, &maxFrameIndex, parentFrame, &emptyFrameIndex, 0, &pageToEvict,
        &frameToEvict, 0, 0, 0, 0, &parentPageToEvict, &positionInParentPage, &isFrameEmpty);

    if (emptyFrameIndex) {
        return emptyFrameIndex;
    }
    bool hasFreeFrame = maxFrameIndex + 1 < NUM_FRAMES;
    if (hasFreeFrame) {
        return maxFrameIndex + 1; // There is an unused frame
    } else {
        PMevict(frameToEvict, pageToEvict);
        // Clears the previous parent page (that was used)
        PMwrite((parentPageToEvict) * PAGE_SIZE + positionInParentPage, 0);
        return frameToEvict;
    }
}

/**
 * Converts a virtual address to a physical address
 * @param virtualAddress - the virtual address to convert
 * @return corresponding physical address
 */
uint64_t convertToPhysicalAddress(uint64_t virtualAddress) {
    uint64_t protectedFrame = 0;
    uint64_t offset = virtualAddress % PAGE_SIZE;
    word_t nextFrameAddr = 0;
    uint64_t baseAddr = 0;
    for (int i = 0; i < TABLES_DEPTH; ++i) {
        uint64_t tableIndex = (virtualAddress >> ((TABLES_DEPTH - i) * OFFSET_WIDTH)) % PAGE_SIZE;
        PMread(baseAddr + tableIndex, &nextFrameAddr);
        if (nextFrameAddr == 0) {
            uint64_t evictedFrame = findEvictionAddress(protectedFrame, protectedFrame, i);
            if (i == TABLES_DEPTH - 1) { // Reached tree leaves, restore evicted frame
                PMrestore(evictedFrame, virtualAddress >> OFFSET_WIDTH);
            } else {
                clearFrame(evictedFrame);
            }
            PMwrite(baseAddr + tableIndex, evictedFrame);
            nextFrameAddr = evictedFrame;
        }
        protectedFrame = nextFrameAddr;
        baseAddr = PAGE_SIZE * nextFrameAddr;
    }
    return nextFrameAddr * PAGE_SIZE + offset;
}

void VMinitialize() {
    clearFrame(0);
}

int VMread(uint64_t virtualAddress, word_t* value) {
    if (virtualAddress >= VIRTUAL_MEMORY_SIZE) {
        return 0;
    }
    uint64_t physicalAddress = convertToPhysicalAddress(virtualAddress);
    PMread(physicalAddress, value);
    return 1;
}

int VMwrite(uint64_t virtualAddress, word_t value) {
    if (virtualAddress >= VIRTUAL_MEMORY_SIZE) {
        return 0;
    }
    uint64_t physicalAddress = convertToPhysicalAddress(virtualAddress);
    PMwrite(physicalAddress, value);
    return 1;
}
